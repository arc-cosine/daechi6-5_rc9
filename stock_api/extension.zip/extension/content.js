(() => {
    // 1. .my-2.5 클래스 내 점(.)은 역슬래시로 이스케이프
    const targetDiv = document.querySelector('div.flex.flex-row.justify-end.flex-wrap.space-x-1.my-2\\.5');
    if (!targetDiv) {
        console.warn('타겟 div를 찾지 못했습니다.');
        return;
    }

    // 2. 저장하기 버튼 생성
    const btn = document.createElement('button');
    btn.textContent = '통계에 반영하기 (by. Arin)';
    btn.className = 'rounded-md shadow-sm my-0.5 px-4 py-2 bg-puple-600 hover:bg-puple-500 text-base font-medium text-white';

    // 3. 저장 함수
    async function saveInputsToJsonbin() {
        try {
            const inputs = document.querySelectorAll('input.text-center.w-full.min-w-28.border.border-gray-350.py-2.px-2.rounded.focus\\:ring-puple-500.focus\\:border-puple-500');
            if (!inputs.length) {
                alert('해당 클래스 input이 없습니다.');
                return;
            }

            const newValues = Array.from(inputs).map(el => el.value);

            const binId = '68974accae596e708fc5efb2'; // jsonbin bin id
            const apiKey = '$2a$10$v8MnmFSL/GoywF.qohAheOJAFCQDPmBW20gtMMHbxdN/zrkvUU1MW'; // 여기에 실제 키 넣기

            let existingData = [];
            try {
                const res = await fetch(`https://api.jsonbin.io/v3/b/${binId}/latest`, {
                    headers: { 'X-Master-Key': apiKey }
                });
                if (res.ok) {
                    const json = await res.json();
                    existingData = json.record?.data || [];
                }
            } catch (e) {
                console.warn('기존 데이터 불러오기 실패:', e.message);
            }

            const combinedData = existingData.concat(newValues);
            const body = { data: combinedData };

            const putRes = await fetch(`https://api.jsonbin.io/v3/b/${binId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Master-Key': apiKey,
                    'X-Bin-Versioning': 'false'
                },
                body: JSON.stringify(body)
            });

            if (putRes.ok) {
                alert('성공적으로 저장되었습니다. 누적 값 개수: ' + combinedData.length);
            } else {
                alert('저장 실패: ' + putRes.statusText);
            }
        } catch (e) {
            alert('오류: ' + e.message);
        }
    }

    // 4. 버튼 클릭 이벤트에 저장 함수 연결
    btn.addEventListener('click', async (e) => {
        e.preventDefault();
        await saveInputsToJsonbin();
    });

    // 5. div에 버튼 추가
    targetDiv.appendChild(btn);
})();
